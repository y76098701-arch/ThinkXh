import fs from 'node:fs';
const [databaseId,teamDomain,aud]=process.argv.slice(2);
if(!/^[0-9a-f-]{36}$/i.test(databaseId||'')||!/^[a-z0-9-]+\.cloudflareaccess\.com$/.test(teamDomain||'')||!aud){console.error('Usage: npm run setup -- DATABASE_ID TEAM.cloudflareaccess.com AUD');process.exit(1);}
const p='wrangler.json',c=JSON.parse(fs.readFileSync(p,'utf8'));c.d1_databases[0].database_id=databaseId;c.vars.ACCESS_TEAM_DOMAIN=teamDomain;c.vars.ACCESS_AUD=aud;fs.writeFileSync(p,JSON.stringify(c,null,2)+'\n');console.log('Configuration saved. Now run npm run build and npm run deploy.');
