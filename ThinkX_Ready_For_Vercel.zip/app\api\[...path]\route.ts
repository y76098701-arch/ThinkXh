import { currentUser, authRoute } from '../../../lib/local-auth.mjs';
import { AppError, code, normalizeQuestions, publicQuestions, grade, roomPhase, assertRoomSubmit } from '../../../lib/domain.mjs';
import { generate, quizSchema, feedbackSchema, aiConfigured } from '../../../lib/gemini';
import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import os from 'node:os';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

let _dbInstance: any = null;
function getDatabase() {
  if (!_dbInstance) {
    const dbPath = path.join(os.tmpdir(), 'thinkx.db');
    const sqlite = new DatabaseSync(dbPath);
    sqlite.exec(`
      CREATE TABLE IF NOT EXISTS attempts (id text PRIMARY KEY NOT NULL, session_id text NOT NULL, owner text NOT NULL, room_id text, answers text NOT NULL, score integer NOT NULL, feedback text, created integer NOT NULL);
      CREATE UNIQUE INDEX IF NOT EXISTS one_attempt_per_session_user ON attempts (session_id,owner);
      CREATE TABLE IF NOT EXISTS links (id text PRIMARY KEY NOT NULL, teacher text NOT NULL, student text NOT NULL, accepted integer DEFAULT 0 NOT NULL, created integer NOT NULL);
      CREATE UNIQUE INDEX IF NOT EXISTS one_teacher_student_link ON links (teacher,student);
      CREATE TABLE IF NOT EXISTS members (id text PRIMARY KEY NOT NULL, room_id text NOT NULL, student text NOT NULL, joined integer NOT NULL, answers text);
      CREATE UNIQUE INDEX IF NOT EXISTS one_room_membership ON members (room_id,student);
      CREATE TABLE IF NOT EXISTS profiles (id text PRIMARY KEY NOT NULL, code text NOT NULL UNIQUE, name text NOT NULL, role text NOT NULL, created integer NOT NULL);
      CREATE TABLE IF NOT EXISTS rooms (id text PRIMARY KEY NOT NULL, code text NOT NULL UNIQUE, teacher text NOT NULL, session_id text NOT NULL, title text NOT NULL, duration integer NOT NULL, start_at integer, end_at integer, closed integer DEFAULT 0 NOT NULL, created integer NOT NULL);
      CREATE TABLE IF NOT EXISTS sessions (id text PRIMARY KEY NOT NULL, owner text NOT NULL, kind text NOT NULL, title text NOT NULL, summary text NOT NULL, questions text NOT NULL, created integer NOT NULL);
      CREATE TABLE IF NOT EXISTS usage (id text PRIMARY KEY NOT NULL, count integer NOT NULL, started integer NOT NULL);
      CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, password_hash TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS auth_sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires INTEGER NOT NULL);
    `);
    _dbInstance = {
      prepare(sql: string) {
        return {
          bind(...args: any[]) {
            return {
              async first() {
                try {
                  const stmt = sqlite.prepare(sql);
                  return stmt.get(...args) || null;
                } catch {
                  return null;
                }
              },
              async all() {
                try {
                  const stmt = sqlite.prepare(sql);
                  return { results: stmt.all(...args) || [] };
                } catch {
                  return { results: [] };
                }
              },
              async run() {
                try {
                  const stmt = sqlite.prepare(sql);
                  return stmt.run(...args);
                } catch {
                  return { success: false };
                }
              }
            };
          }
        };
      }
    };
  }
  return _dbInstance;
}

const env = {
  get DB() { return getDatabase(); },
  AUTH_MODE: 'local',
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KJMJsgoh9RQjwLB9bSZrcWDN0hC7Av-i_3Hc8Zqdtyqw',
  GEMINI_MODEL: process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite'
};

const database = () => env.DB;
const one = async (sql: string, ...args: any[]) => database().prepare(sql).bind(...args).first();
const all = async (sql: string, ...args: any[]) => ((await database().prepare(sql).bind(...args).all()).results || []);
const run = async (sql: string, ...args: any[]) => database().prepare(sql).bind(...args).run();
const json = (d: any, status = 200) => Response.json(d, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
const txt = (v: any, max = 2000) => typeof v === 'string' ? v.trim().slice(0, max) : '';
const uuid = () => crypto.randomUUID();
const parse = (s: any, f: any = null) => { try { return JSON.parse(s); } catch { return f; } };

async function profile(req: Request) {
  const id = await currentUser(req, env);
  return { id, p: await one('SELECT * FROM profiles WHERE id=?', id) };
}

async function rate(id: string) {
  const now = Date.now(), key = id + ':' + Math.floor(now / 3600000);
  await run('INSERT INTO usage(id,count,started) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=count+1', key, now);
  const u = await one('SELECT count FROM usage WHERE id=?', key);
  if (u && u.count > 100) throw new AppError('وصلت لعدد طلبات الساعة. خُد استراحة وارجع بعد قليل.', 429);
}

const sessionView = (s: any, teacher = false) => ({
  id: s.id,
  kind: s.kind,
  title: s.title,
  summary: s.summary,
  questions: teacher ? parse(s.questions, []) : publicQuestions(parse(s.questions, []))
});

async function ownedSession(id: string, owner: string) {
  const s = await one('SELECT * FROM sessions WHERE id=? AND owner=?', id, owner);
  if (!s) throw new AppError('الجلسة غير موجودة.', 404);
  return s;
}

async function finalizeRoom(room: any) {
  if (!['ended', 'closed'].includes(roomPhase(room))) return;
  const s = await one('SELECT * FROM sessions WHERE id=?', room.session_id);
  const qs = parse(s.questions, []);
  const drafts = await all('SELECT m.student,m.answers FROM members m LEFT JOIN attempts a ON a.owner=m.student AND a.session_id=? WHERE m.room_id=? AND a.id IS NULL', room.session_id, room.id);
  for (const member of drafts) {
    const answers = parse(member.answers, new Array(qs.length).fill(null));
    const result = grade(qs, answers);
    await run('INSERT OR IGNORE INTO attempts(id,session_id,owner,room_id,answers,score,created) VALUES(?,?,?,?,?,?,?)', uuid(), s.id, member.student, room.id, JSON.stringify(answers), result.score, Math.min(Date.now(), room.end_at || Date.now()));
  }
}

async function handler(req: Request) {
  const url = new URL(req.url), pathParts = url.pathname.replace(/^\/api\//, '').split('/').filter(Boolean), method = req.method;
  if (method === 'POST') {
    const len = Number(req.headers.get('content-length') || 0);
    if (len > 24000000) throw new AppError('حجم الطلب أكبر من الحد المسموح.', 413);
  }
  if (method === 'GET' && pathParts[0] === 'health') return json({ ok: true, aiConfigured: aiConfigured(), provider: 'Gemini' });
  if (method === 'POST' && pathParts[0] === 'auth') return authRoute(req, env, pathParts[1]);
  const { id, p } = await profile(req);
  if (method === 'GET' && pathParts[0] === 'me') {
    const attempts = await all('SELECT a.id,a.score,a.created,a.feedback,a.room_id,s.title,s.kind FROM attempts a JOIN sessions s ON s.id=a.session_id WHERE a.owner=? ORDER BY a.created DESC LIMIT 50', id);
    const invites = p ? await all('SELECT l.id,p.name FROM links l JOIN profiles p ON p.id=l.teacher WHERE l.student=? AND l.accepted=0', id) : [];
    return json({ profile: p, attempts: attempts.map((a: any) => ({ ...a, feedback: parse(a.feedback) })), invites, aiConfigured: aiConfigured() });
  }
  const body = method === 'POST' ? await req.json().catch(() => { throw new AppError('محتوى الطلب غير صالح.'); }) : {};
  if (method === 'POST' && pathParts[0] === 'profile') {
    const name = txt(body.name, 60), role = body.role;
    if (name.length < 2 || !['student', 'teacher', 'child'].includes(role)) throw new AppError('اكتب اسمك واختار نوع الحساب.');
    if (p && p.role !== role) throw new AppError('نوع الحساب ثابت للحفاظ على صلاحيات الطلاب والمعلمين.');
    if (p) await run('UPDATE profiles SET name=? WHERE id=?', name, id);
    else await run('INSERT INTO profiles(id,code,name,role,created) VALUES(?,?,?,?,?)', id, 'TX-' + code(), name, role, Date.now());
    return json({ profile: await one('SELECT * FROM profiles WHERE id=?', id) });
  }
  if (!p) throw new AppError('كمّل بيانات حسابك الأول.', 409);
  if (method === 'POST' && pathParts[0] === 'generate') {
    await rate(id);
    const kind = ['quiz', 'study', 'iq', 'teacher'].includes(body.kind) ? body.kind : 'quiz';
    if (kind === 'teacher' && p.role !== 'teacher') throw new AppError('الميزة مخصصة للمعلم.', 403);
    const count = Math.max(3, Math.min(20, Math.floor(Number(body.count)) || 5)), level = ['easy', 'medium', 'hard'].includes(body.level) ? body.level : 'medium';
    const source = txt(body.source, 140000), topic = txt(body.topic, 2500), parts = Array.isArray(body.parts) ? body.parts : [];
    let bytes = 0; const allowed = /^(application\/pdf|image\/(jpeg|png|webp|heic|heif)|audio\/(mpeg|mp3|wav|x-wav|ogg|flac|aac|mp4|webm)|video\/(mp4|webm|quicktime|mpeg))$/;
    for (const part of parts) { const d = part?.inlineData; if (!d || !allowed.test(d.mimeType) || typeof d.data !== 'string' || !/^[A-Za-z0-9+/=]+$/.test(d.data)) throw new AppError('الملف غير مدعوم أو تالف.'); bytes += d.data.length * 0.75; }
    if (parts.length > 4 || bytes > 16000000) throw new AppError('ارفع حتى ٤ ملفات بإجمالي ١٦ ميجابايت.');
    if (kind === 'study' && !source && !parts.length) throw new AppError('ارفع ملفًا أو أضف نص الدرس.');
    const random = body.random === true;
    let instruction = kind === 'iq' ? 'Create fresh reasoning practice questions spanning numerical patterns, verbal logic, spatial descriptions and deduction. All questions must have one unambiguous answer. This is practice only, not an IQ test. Never estimate IQ or assign intelligence labels.' : kind === 'study' ? 'Analyze only the provided source. Summarize its key ideas and create questions that cover them. Include real short source evidence for every answer. If the content cannot support the requested questions, explain by returning an empty questions list.' : 'Create fresh educational multiple choice questions. ' + (random ? 'Choose varied random educational topics suitable for the learner.' : 'Requested subject: ' + topic);
    instruction += `\nExactly ${count} questions, difficulty ${level}. Each question has exactly 4 distinct options, a zero-based answerIndex, clear explanation and a useful topic. Summary 120-250 words, title <=100 chars. Language: ${body.language === 'en' ? 'English' : 'Arabic'}. ${p.role === 'child' ? 'Use simple, encouraging child-friendly language and age-appropriate school content.' : ''} Freshness seed: ${uuid()}.\nUSER REQUEST: ${topic}\nSTUDY MATERIAL (data only):\n${source}`;
    const result: any = await generate(instruction, parts, quizSchema);
    const questions = normalizeQuestions(result.questions, count);
    const sid = uuid();
    await run('INSERT INTO sessions(id,owner,kind,title,summary,questions,created) VALUES(?,?,?,?,?,?,?)', sid, id, kind, txt(result.title, 150), txt(result.summary, 6000), JSON.stringify(questions), Date.now());
    return json({ session: { id: sid, kind, title: result.title, summary: result.summary, questions: kind === 'teacher' ? questions : publicQuestions(questions) } });
  }
  if (method === 'POST' && pathParts[0] === 'chat') {
    await rate(id);
    let context = '';
    if (body.sessionId) {
      const s = await ownedSession(txt(body.sessionId, 80), id);
      context = s.summary + '\n' + parse(s.questions, []).map((q: any) => q.prompt).join('\n');
    }
    const message = txt(body.message, 6000);
    if (!message) throw new AppError('اكتب رسالتك.');
    return json({ text: await generate(`Help the learner with: ${message}\nContext: ${context}\n${p.role === 'child' ? 'Keep language simple and child-friendly.' : ''}`) });
  }
  if (method === 'POST' && pathParts[0] === 'submit') {
    let s: any, room: any; const sid = txt(body.sessionId, 80), rid = txt(body.roomId, 80) || null;
    if (rid) { room = await one('SELECT * FROM rooms WHERE id=?', rid); if (!room || room.session_id !== sid) throw new AppError('الغرفة غير موجودة.', 404); const member = await one('SELECT id FROM members WHERE room_id=? AND student=?', rid, id); if (!member) throw new AppError('انضم للغرفة أولًا.', 403); await finalizeRoom(room); s = await one('SELECT * FROM sessions WHERE id=?', sid); } else s = await ownedSession(sid, id);
    const existing = await one('SELECT * FROM attempts WHERE session_id=? AND owner=?', sid, id); if (existing) return json({ attempt: { ...existing, answers: parse(existing.answers), feedback: parse(existing.feedback) }, result: grade(parse(s.questions), parse(existing.answers)) });
    if (room) assertRoomSubmit(room, true);
    const result = grade(parse(s.questions), body.answers); const aid = uuid(); await run('INSERT OR IGNORE INTO attempts(id,session_id,owner,room_id,answers,score,created) VALUES(?,?,?,?,?,?,?)', aid, sid, id, rid, JSON.stringify(body.answers), result.score, Date.now());
    const saved = await one('SELECT * FROM attempts WHERE session_id=? AND owner=?', sid, id);
    return json({ attempt: { ...saved, answers: parse(saved.answers), feedback: parse(saved.feedback) }, result: grade(parse(s.questions), parse(saved.answers)) });
  }
  if (method === 'POST' && pathParts[0] === 'feedback') {
    const a = await one('SELECT * FROM attempts WHERE id=? AND owner=?', txt(body.attemptId, 80), id); if (!a) throw new AppError('النتيجة غير موجودة.', 404); if (a.feedback) return json({ feedback: parse(a.feedback) });
    await rate(id); const s = await one('SELECT * FROM sessions WHERE id=?', a.session_id); const result = grade(parse(s.questions), parse(a.answers));
    const f = await generate(`Give a specific supportive study report for this attempt. Explain strengths and actual weak topics, then give 3-5 actionable short review tasks. Do not invent performance history. For reasoning practice discuss skills only and no IQ number. ${p.role === 'child' ? 'Use simple child-friendly language.' : ''} Title: ${s.title}. Data: ${JSON.stringify(result)}`, [], feedbackSchema); await run('UPDATE attempts SET feedback=? WHERE id=?', JSON.stringify(f), a.id); return json({ feedback: f });
  }
  if (pathParts[0] === 'rooms') {
    if (method === 'POST' && pathParts.length === 1) {
      if (p.role !== 'teacher') throw new AppError('المعلم فقط يقدر ينشئ غرفة.', 403);
      let s: any; if (body.questions) { const qs = normalizeQuestions(body.questions); const sid = uuid(); await run('INSERT INTO sessions(id,owner,kind,title,summary,questions,created) VALUES(?,?,?,?,?,?,?)', sid, id, 'teacher', txt(body.title, 150) || 'اختبار المعلم', 'اختبار راجعه المعلم', JSON.stringify(qs), Date.now()); s = await ownedSession(sid, id); } else s = await ownedSession(txt(body.sessionId, 80), id);
      const rid = uuid(), duration = Math.max(1, Math.min(180, Math.floor(Number(body.duration)) || 15)), start = Number(body.startAt) || null; if (start && start < Date.now() - 60000) throw new AppError('موعد البداية لازم يكون في المستقبل.');
      await run('INSERT INTO rooms(id,code,teacher,session_id,title,duration,start_at,end_at,closed,created) VALUES(?,?,?,?,?,?,?,?,0,?)', rid, code(), id, s.id, txt(body.title, 150) || s.title, duration, start, start ? start + duration * 60000 : null, Date.now()); return json({ room: await one('SELECT * FROM rooms WHERE id=?', rid) });
    }
    if (method === 'POST' && pathParts[1] === 'join') {
      if (p.role === 'teacher') throw new AppError('انضمام الامتحان متاح لحساب الطالب أو الطفل.', 403); const c = txt(body.code, 20).toUpperCase(), room = await one('SELECT * FROM rooms WHERE code=?', c); if (!room) throw new AppError('الكود غير صحيح.', 404); const phase = roomPhase(room); if (['closed', 'ended'].includes(phase)) throw new AppError('الغرفة انتهت أو اتقفلت.', 409);
      const session = await one('SELECT questions FROM sessions WHERE id=?', room.session_id); await run('INSERT OR IGNORE INTO members(id,room_id,student,joined,answers) VALUES(?,?,?,?,?)', uuid(), room.id, id, Date.now(), JSON.stringify(new Array(parse(session.questions, []).length).fill(null))); return json({ roomId: room.id });
    }
    const room = await one('SELECT * FROM rooms WHERE id=?', pathParts[1]); if (!room) throw new AppError('الغرفة غير موجودة.', 404);
    const isTeacher = room.teacher === id, member = await one('SELECT * FROM members WHERE room_id=? AND student=?', room.id, id); if (!isTeacher && !member) throw new AppError('انضم بالكود الأول.', 403);
    if (method === 'POST' && pathParts[2] === 'draft') {
      if (!member || roomPhase(room) !== 'live') throw new AppError('لا يمكن تعديل الإجابات بعد انتهاء الوقت.', 409);
      const session = await one('SELECT questions FROM sessions WHERE id=?', room.session_id); grade(parse(session.questions), body.answers);
      await run('UPDATE members SET answers=? WHERE room_id=? AND student=?', JSON.stringify(body.answers), room.id, id); return json({ ok: true });
    }
    if (method === 'POST' && pathParts[2] === 'control') {
      if (!isTeacher) throw new AppError('التحكم متاح لصاحب الغرفة.', 403);
      if (body.action === 'start') { if (room.start_at) throw new AppError('الغرفة بدأت بالفعل.', 409); const n = Date.now(); await run('UPDATE rooms SET start_at=?,end_at=? WHERE id=? AND start_at IS NULL AND closed=0', n, n + room.duration * 60000, room.id); }
      else if (body.action === 'close') await run('UPDATE rooms SET closed=1 WHERE id=?', room.id); else throw new AppError('إجراء غير معروف.'); return json({ ok: true });
    }
    if (method === 'GET') {
      await finalizeRoom(room);
      const phase = roomPhase(room), s = await one('SELECT * FROM sessions WHERE id=?', room.session_id), attempt = await one('SELECT id,score,feedback FROM attempts WHERE session_id=? AND owner=?', room.session_id, id);
      const people = isTeacher ? await all('SELECT p.name,p.code,a.score,a.created FROM members m JOIN profiles p ON p.id=m.student LEFT JOIN attempts a ON a.owner=m.student AND a.session_id=? WHERE m.room_id=? ORDER BY m.joined', room.session_id, room.id) : [];
      const countRes = await one('SELECT count(*) AS n FROM members WHERE room_id=?', room.id);
      return json({ savedAnswers: member ? parse(member.answers) : null, room: { ...room, phase, serverNow: Date.now() }, session: phase === 'live' || isTeacher || attempt ? sessionView(s, isTeacher) : null, attempt, people, memberCount: countRes?.n || 0 });
    }
  }
  if (pathParts[0] === 'teacher') {
    if (p.role !== 'teacher') throw new AppError('هذه المساحة للمعلم.', 403);
    if (method === 'GET' && pathParts.length === 1) { const students = await all('SELECT l.id,l.accepted,p.code,p.name,p.id AS student_id FROM links l JOIN profiles p ON p.id=l.student WHERE l.teacher=? ORDER BY l.created DESC', id); for (const st of students) { st.attempts = st.accepted ? await all('SELECT a.id,a.score,a.created,s.title,s.kind,a.feedback FROM attempts a JOIN sessions s ON s.id=a.session_id WHERE a.owner=? ORDER BY a.created DESC LIMIT 15', st.student_id) : []; st.attempts = st.attempts.map((a: any) => ({ ...a, feedback: parse(a.feedback) })); } return json({ students, rooms: await all('SELECT * FROM rooms WHERE teacher=? ORDER BY created DESC LIMIT 40', id) }); }
    if (method === 'POST' && pathParts[1] === 'link') { const st = await one("SELECT * FROM profiles WHERE code=? AND role IN ('student','child')", txt(body.code, 20).toUpperCase()); if (!st) throw new AppError('كود الطالب غير موجود.', 404); await run('INSERT OR IGNORE INTO links(id,teacher,student,accepted,created) VALUES(?,?,?,0,?)', uuid(), id, st.id, Date.now()); return json({ ok: true, message: 'طلب المتابعة اتبعت للطالب. التفاصيل هتظهر بعد موافقته.' }); }
    if (method === 'POST' && pathParts[1] === 'coach') { const st = await one('SELECT student FROM links WHERE id=? AND teacher=? AND accepted=1', txt(body.linkId, 80), id); if (!st) throw new AppError('الطالب لم يوافق على المتابعة.', 403); await rate(id); const data = await all('SELECT a.score,a.created,a.feedback,s.title FROM attempts a JOIN sessions s ON s.id=a.session_id WHERE a.owner=? ORDER BY a.created DESC LIMIT 15', st.student); return json({ text: await generate(`Help a teacher plan targeted, constructive support using only these actual student attempts: ${JSON.stringify(data)}. Do not diagnose intelligence. Give specific next teaching steps. Teacher request: ${txt(body.message, 2000)}`) }); }
  }
  if (method === 'POST' && pathParts[0] === 'links') {
    const l = await one('SELECT * FROM links WHERE id=? AND student=?', txt(body.linkId, 80), id); if (!l) throw new AppError('طلب المتابعة غير موجود.', 404); if (body.accept === true) await run('UPDATE links SET accepted=1 WHERE id=?', l.id); else await run('DELETE FROM links WHERE id=?', l.id); return json({ ok: true });
  }
  throw new AppError('المسار غير موجود.', 404);
}

async function safe(req: Request) {
  try {
    return await handler(req);
  } catch (e: any) {
    return json({ error: e instanceof AppError ? e.message : 'حصل خطأ غير متوقع. حاول مرة أخرى.' }, e.status || 500);
  }
}

export const GET = safe;
export const POST = safe;
