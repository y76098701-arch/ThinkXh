import test from 'node:test';import assert from 'node:assert/strict';
import {normalizeQuestions,publicQuestions,grade,roomPhase,assertRoomSubmit} from '../lib/domain.mjs';
const qs=normalizeQuestions([{prompt:'What is 2 + 2?',options:['1','2','3','4'],answerIndex:3,explanation:'2 + 2 = 4',topic:'Addition'}]);
test('student question payload never exposes answer or evidence',()=>{const q=publicQuestions(qs)[0];assert.equal(q.answerIndex,undefined);assert.equal(q.explanation,undefined);assert.equal(q.evidence,undefined);});
test('grading uses saved answers and counts unanswered questions',()=>{assert.equal(grade(qs,[3]).score,100);assert.equal(grade(qs,[null]).score,0);assert.throws(()=>grade(qs,[4]));});
test('malformed generated content cannot become an exam',()=>{assert.throws(()=>normalizeQuestions([{...qs[0],options:['same','same','x','y']}]));assert.throws(()=>normalizeQuestions(qs,5));});
test('server owns the room clock and enrollment',()=>{const r={start_at:1000,end_at:61000,closed:0};assert.equal(roomPhase(r,100),'waiting');assert.equal(roomPhase(r,2000),'live');assert.equal(roomPhase(r,61000),'ended');assert.throws(()=>assertRoomSubmit(r,false,2000));assert.throws(()=>assertRoomSubmit(r,true,500));assert.throws(()=>assertRoomSubmit(r,true,72000));assert.doesNotThrow(()=>assertRoomSubmit(r,true,62000));});
