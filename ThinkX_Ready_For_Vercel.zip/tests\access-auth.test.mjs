import test from 'node:test';import assert from 'node:assert/strict';
import {accessUser} from '../lib/access-auth.mjs';import {token,settings,fetchKeys} from './access-fixture.mjs';
const request=t=>new Request('https://thinkx.example/api/me',{headers:t?{'Cf-Access-Jwt-Assertion':t}:{'oai-authenticated-user-id':'spoofed'}});
test('signed Access token establishes a stable user identity',async()=>{assert.equal(await accessUser(request(await token()),settings,fetchKeys),'https://'+settings.ACCESS_TEAM_DOMAIN+'|student');});
test('plain identity headers cannot impersonate a user',async()=>{await assert.rejects(()=>accessUser(request(),settings,fetchKeys),e=>e.status===401);});
test('reject expired tokens, wrong audiences and wrong issuers',async()=>{for(const overrides of [{exp:1},{aud:['wrong']},{iss:'https://other.cloudflareaccess.com'}])await assert.rejects(async()=>accessUser(request(await token('x',overrides)),settings,fetchKeys),e=>e.status===401);});
test('reject invalid signatures and unsupported algorithms',async()=>{const t=await token();const parts=t.split('.');const sig=Buffer.from(parts[2],'base64url');sig[0]^=1;parts[2]=sig.toString('base64url');await assert.rejects(()=>accessUser(request(parts.join('.')),settings,fetchKeys));await assert.rejects(async()=>accessUser(request(await token('x',{}, {alg:'none'})),settings,fetchKeys));});
test('missing deployment settings fail closed',async()=>{await assert.rejects(()=>accessUser(request(),{},fetchKeys),e=>e.status===503);});
