import type { Metadata } from 'next';
export const metadata:Metadata={title:'ThinkX | مساحة تعلم بالذكاء الاصطناعي',description:'تعلّم بطريقتك مع Gemini وغرف امتحانات للطلاب والمعلمين'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><body>{children}</body></html>;}
