const encoder=new TextEncoder();
const pair=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
export const jwk={...await crypto.subtle.exportKey('jwk',pair.publicKey),kid:'test-key',alg:'RS256',use:'sig'};
export const settings={ACCESS_TEAM_DOMAIN:'thinkx-test.cloudflareaccess.com',ACCESS_AUD:'thinkx-test-aud'};
const b64=b=>Buffer.from(b).toString('base64url');
export async function token(sub='student',overrides={},head={}){const h=b64(JSON.stringify({alg:'RS256',kid:jwk.kid,...head}));const p=b64(JSON.stringify({iss:'https://'+settings.ACCESS_TEAM_DOMAIN,aud:[settings.ACCESS_AUD],sub,email:'test@example.com',exp:Math.floor(Date.now()/1000)+3600,...overrides}));const signature=await crypto.subtle.sign('RSASSA-PKCS1-v1_5',pair.privateKey,encoder.encode(h+'.'+p));return h+'.'+p+'.'+b64(signature);}
export const fetchKeys=async()=>Response.json({keys:[jwk]});
