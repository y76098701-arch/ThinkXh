# نشر ThinkX على حسابك في Cloudflare

هذه نسخة مستقلة جديدة باسم ThinkX_SelfHost_Cloudflare.zip. لا تستخدم ZIP القديم مع هذه الأوامر. الاستضافة تكون على حسابك، والطلاب يدخلون بكود يصل إلى إيميلهم، دون حساب ChatGPT. Node مطلوب على جهاز من ينشر الموقع فقط. بعد النشر يمكن إغلاق الكمبيوتر.

قبل البدء: تحتاج حساب Cloudflare وبريدًا تستقبل عليه الرسائل ومفتاح Gemini من Google AI Studio. تفعيل Cloudflare Zero Trust له خطوات اشتراك منفصلة، والتوثيق الرسمي يذكر إدخال بيانات دفع حتى عند اختيار Free. راجع ما تعرضه حسابك وحدود الخطط قبل التأكيد. لا يوجد ضمان تشغيل بلا حدود أو بلا تكلفة لأي حجم استخدام.

## 1. البرنامج والملفات

1. حمّل Node.js 24 LTS من https://nodejs.org/en/download واختر Windows Installer لو جهازك Windows. اختبرت المشروع على Node 24.
2. فك ضغط ThinkX_SelfHost_Cloudflare.zip في مكان بسيط مثل C:\ThinkX.
3. افتح المجلد الداخلي ThinkX. يجب أن ترى package.json وwrangler.json وpublic وapp.
4. افتح شريط عنوان File Explorer، واكتب cmd ثم Enter. ستفتح نافذة الأوامر داخل مجلد المشروع. نفّذ كل الأوامر التالية هنا، وليس داخل public.
5. تأكد من التثبيت:

    node -v
    npm -v

6. نزّل مكتبات المشروع:

    npm ci

انتظر حتى ينتهي الأمر. لا ترفع node_modules أو public يدويًا إلى Pages.

## 2. الدخول إلى Cloudflare

افتح https://dash.cloudflare.com وأنشئ حسابًا أو ادخل حسابك، ثم فعّل بريدك.

في نافذة الأوامر:

    npx wrangler login

يفتح المتصفح. اختر حسابك ووافق على ربط أداة Wrangler بحسابك ثم ارجع إلى CMD. لا ترسل بيانات الدخول لأحد. لو لديك أكثر من حساب، اختر نفس الحساب في كل مراحل الدليل.

## 3. إنشاء قاعدة البيانات

نفّذ:

    npx wrangler d1 create thinkx-db

سيظهر database_id. انسخ القيمة الفعلية التي رجعت لك، وليست اسم قاعدة البيانات. ضعها بدل YOUR_DATABASE_ID:

    node scripts/configure-db.mjs YOUR_DATABASE_ID

ثم نفّذ:

    npm run db:apply

الأمر ينشئ جداول المشروع على D1 البعيدة. وافق عند طلب التأكيد. لا تعاود إنشاء قاعدة أخرى إذا نجحت هذه الخطوة؛ احتفظ بنفس database_id.

## 4. رفع أول نسخة

نفّذ الأمرين بالتتابع:

    npm run build
    npm run deploy

عند النجاح ستجد رابطًا ينتهي بـ workers.dev، بصيغة عامة:

    https://thinkx.YOUR_SUBDOMAIN.workers.dev

هذا مثال لصيغة الرابط فقط، وليس رابط مشروعك. احتفظ بالرابط الفعلي الذي ظهر. هذه رفعة أولى قبل إعداد الدخول؛ ظهور رسالة إعدادات الدخول غير مكتملة في هذه المرحلة متوقع.

لو طلب Cloudflare اختيار workers.dev subdomain، اكتب اسمًا مناسبًا للمشروع بدل اسم إيميلك. اسم الموقع في wrangler.json هو thinkx. إذا لديك Worker مهم موجود بنفس الاسم، غيّر name إلى اسم جديد قبل أول نشر حتى لا تستبدله.

## 5. وضع مفتاح Gemini كمتغير سري

نفّذ:

    npx wrangler secret put GEMINI_API_KEY --config wrangler.json --name thinkx

عندما يطلب القيمة، الصق مفتاح Gemini واضغط Enter. لا تضع المفتاح بين كلمات الأمر أو داخل ملفات HTML/JavaScript. إذا غيّرت اسم Worker في المرحلة السابقة، استبدل thinkx في --name بالاسم الذي اخترته.

بديل من لوحة Cloudflare: Workers & Pages ثم Worker الخاص بك، ثم إعدادات Variables and Secrets. أضف GEMINI_API_KEY من نوع Secret واحفظه/انشره بحسب الزر الظاهر في حسابك. لا تضف مفتاحًا في ملف public.

## 6. إعداد الدخول بالإيميل OTP

1. افتح Cloudflare Zero Trust من حسابك وأكمل إنشاء المؤسسة. اختر اسم فريق متاحًا. احتفظ بالـteam domain الذي ينتهي بـcloudflareaccess.com.
2. اختر الخطة المناسبة وراجع الحدود التي يعرضها حسابك. تفعيل Free قد يطلب بيانات دفع وفق دليل Cloudflare الرسمي.
3. افتح Zero Trust > Integrations > Identity providers.
4. اضغط Add new identity provider، واختر One-time PIN. فعّله واحفظه. لا تعتمد على الاختيار الافتراضي؛ المؤسسات الجديدة قد تبدأ بطريقة Cloudflare account بدل OTP.
5. افتح Zero Trust > Access controls > Applications. قد تظهر باسم Access > Applications حسب الواجهة.
6. اضغط Add an application ثم Self-hosted.
7. سمّ التطبيق ThinkX. أضف في Public hostname النطاق الكامل لرابط workers.dev الذي رجع لك في الخطوة 4، دون https:// ودون /index.html. اجعل التطبيق يحمي الموقع كله، لا مسار API أو صفحة واحدة فقط.
8. أضف سياسة اسمها ThinkX users، Action = Allow، وبداخل Include اختَر Emails وأضف بريدك وبريد طالب تجريبي أو أعضاء الفريق الذين ستسمح لهم بالدخول. الطلاب لا يحتاجون حساب Cloudflare إداريًا.
9. في Login methods اختر One-time PIN. احفظ التطبيق والسياسة. هذا يمنح البريد المضاف حق فتح الموقع؛ نوع حسابه داخل ThinkX يختاره عند أول دخول.
10. افتح إعدادات تطبيق ThinkX ثم Additional settings، وانسخ Application Audience (AUD) Tag.

مهم: البريد غير الموجود في Allow policy لن يستقبل كودًا، حتى لو قالت صفحة الدخول إن الكود أُرسل. أضف إيميلات الطلاب في هذه السياسة قبل دعوتهم. لا تضف سياسة Bypass؛ الكود يحتاج هوية موثّقة.

## 7. ربط الدخول بالمشروع وإعادة النشر

أصبح عندك ثلاث قيم فعلية:

- database_id من الخطوة 3.
- team domain، مثل your-team.cloudflareaccess.com، من حسابك الفعلي.
- AUD tag لتطبيق ThinkX، من الخطوة 6.

نفّذ، مع استبدال القيم الثلاث:

    npm run setup -- YOUR_DATABASE_ID YOUR_TEAM.cloudflareaccess.com YOUR_AUD_TAG
    npm run build
    npm run deploy

الأمر الأول يعدّل wrangler.json. لا تعدّل dist/server/wrangler.json يدويًا؛ هو ملف ناتج عن البناء. عند تغيير إعدادات المصدر، أعد build ثم deploy. سر Gemini الذي أضفته محفوظ في Cloudflare؛ لا تحتاج إدخاله من جديد لكل تحديث عادي.

## 8. اختبار الدخول والذكاء الاصطناعي

افتح رابطك الفعلي في نافذة خاصة Incognito. اكتب بريدًا مسموحًا به في سياسة Access، ثم أدخل الكود الذي يصلك على البريد. بعد الدخول، اختر اسمك ونوع حسابك في ThinkX.

جرّب أولًا: أسئلة AI > موضوع بسيط > 5 أسئلة > توليد. حل المحاولة وسلّمها. تأكد من ظهور الدرجة والشرح وتقرير المراجعة. ثم جرّب نص درس قصيرًا في مذاكرتي. لا تبدأ بملف كبير عند الاختبار.

يمكنك فتح /api/health على نفس نطاقك بعد تسجيل الدخول. يجب أن يظهر ok:true وaiConfigured:true. هذا يفحص وجود إعداد المفتاح؛ نجاح توليد سؤال فعلي هو الذي يختبر اتصال Gemini وصلاحية المفتاح وحصته.

## 9. اختبار المعلم والطالب من جهازين

1. سجّل ببريدك كمعلم.
2. افتح استوديو المعلم واكتب موضوعًا أو أضف سؤالًا يدويًا. راجع الإجابة الصحيحة.
3. أنشئ غرفة بمدة قصيرة وانسخ الكود.
4. من جهاز آخر أو نافذة خاصة ادخل ببريد مختلف مسموح به في سياسة Access، واختر طالبًا. لا تستخدم نفس البريد للدورين، لأن نوع الحساب ثابت.
5. الطالب يدخل تبويب الفصل ويكتب الكود. المعلم يبدأ الغرفة، والطالب يحل ويسلّم.
6. راجع ظهور النتيجة لدى الطالب والمعلم، ثم حدّث الصفحة وتأكد أن المحاولة محفوظة.
7. للمتابعة خارج غرفة واحدة، الطالب يشارك كوده TX- مع المعلم ويوافق على طلب متابعة تاريخه.

هذه قاعدة بيانات مستقلة. الحسابات والنتائج القديمة على الاستضافة السابقة لا تنتقل تلقائيًا.

## 10. التحديث لاحقًا

بعد تعديل ملفات المصدر، افتح CMD داخل نفس المشروع ونفّذ:

    npm run build
    npm run deploy

إذا تغيرت جداول البيانات، تُضاف ترقية SQL جديدة بدل تعديل ترقية سبق تطبيقها، ثم تطبق الترقيات قبل النشر. لا تنشئ قاعدة جديدة عند كل تحديث؛ نفس DB تحفظ الطلاب والنتائج.

## 11. رابط باسمك

workers.dev يكفي كبداية، ومن غير كلمة ChatGPT. يمكن تغيير account subdomain من Workers & Pages عند Your subdomain > Change. راجع أثر تغييره لو لديك مشاريع أخرى.

لو تملك دومينًا خاصًا، اربطه بالـWorker من Domains أو Domains & Routes حسب لوحة حسابك. ثم أضف النطاق الجديد إلى حماية Access/تطبيق ThinkX قبل استخدامه مع الطلاب. استخدم نفس تطبيق Access أو حدّث AUD إذا أنشأت تطبيقًا جديدًا.

## حل المشكلات

| الرسالة | ما تراجعه |
|---|---|
| node أو npm غير معروف | تثبيت Node ثم إغلاق CMD وفتحه من جديد |
| Cannot find package.json | افتح CMD في المجلد الداخلي الذي يحتوي package.json |
| database not found | نفس database_id ونفس حساب Cloudflare ثم build وdeploy |
| no such table | npm run db:apply على قاعدة البيانات الصحيحة |
| إعدادات الدخول ناقصة | team domain وAUD ثم setup وbuild وdeploy |
| جلسة الدخول غير صالحة | AUD لنفس التطبيق، team domain، وحماية النطاق الكامل |
| كود البريد لا يصل | Allow policy تحتوي البريد، وطريقة One-time PIN مفعّلة، ثم Spam |
| Gemini غير مفعّل | GEMINI_API_KEY موجود كـSecret على Worker الصحيح |
| Gemini رفض الطلب | صلاحية المفتاح وتفعيل Gemini API والملف المرفوع |
| حد الاستخدام أو الخدمة مشغولة | حصة Google أو توافر الخدمة؛ رفع الموقع من جديد لا يحل الحصة |
| الواجهة تظهر لكن الحسابات لا تعمل | لا ترفع public وحده. استخدم حزمة النشر الكاملة والأوامر أعلاه |

## مراجع رسمية

https://developers.cloudflare.com/workers/wrangler/commands/d1/
https://developers.cloudflare.com/workers/configuration/secrets/
https://developers.cloudflare.com/workers/configuration/cloudflare-access/
https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/one-time-pin/
https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/
https://developers.cloudflare.com/cloudflare-one/setup/
