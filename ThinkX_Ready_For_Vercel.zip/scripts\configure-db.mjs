import fs from 'node:fs';
const id=process.argv[2];if(!/^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(id||'')){console.error('Usage: node scripts/configure-db.mjs DATABASE_ID');process.exit(1);}
const p='wrangler.json',c=JSON.parse(fs.readFileSync(p,'utf8'));c.d1_databases[0].database_id=id;fs.writeFileSync(p,JSON.stringify(c,null,2)+'\n');console.log('D1 configured. Run npm run db:apply.');
