# Local project edition

Read START_AR.md first. Includes server-side Gemini configuration and database-backed username/password login. Run npm install then npm run dev. The archive contains a private .dev.vars file.

---

# ThinkX — independent Cloudflare deployment

This package runs on your own Cloudflare Workers account with D1 and Google Gemini. It does not depend on ChatGPT Sites for authentication or hosting. Users authenticate through Cloudflare Access email OTP, then choose Student, Teacher or Child mode inside ThinkX.

Read DEPLOY_AR.md for the complete Windows deployment walkthrough. Use this package instead of ThinkX_Full_Source.zip, which was an export of the previous hosting-specific version.

## Included checks

- npm test: question validation, grading, room clocks and JWT verification.
- node tests/route-harness.mjs: SQLite-backed API integration with signed test identities. No live accounts or mail are created.
- npm run build: creates dist/client and dist/server/wrangler.json.
- npx wrangler deploy --config dist/server/wrangler.json --dry-run: validates the deployment package without publishing.

Live email delivery, your Cloudflare account configuration and Gemini quota require verification after you deploy. This edition includes the supplied Gemini key in a private .dev.vars file; it has not been validated against the provider. Data from the previous deployment is not migrated automatically.

## Runtime configuration

wrangler.json is the source configuration. Do not edit generated dist/server/wrangler.json. Run npm run build after changing source settings.

- D1 binding: DB, database name thinkx-db. Replace the placeholder database_id.
- ACCESS_TEAM_DOMAIN: your actual team hostname, for example your-team.cloudflareaccess.com.
- ACCESS_AUD: Application Audience tag for the Access application protecting this site.
- GEMINI_API_KEY: runtime Secret configured with Wrangler or the dashboard.
- GEMINI_MODEL: source configuration defaults to gemini-3.1-flash-lite and uses a second Gemini model for transient provider failures.

The API verifies Access JWT signatures, issuer, audience and expiry. It does not trust visitor-supplied identity headers. Leaving Access settings empty intentionally prevents login.

Uploads: up to four supported files with a combined 16 MB. Office DOCX/PPTX/XLSX are extracted as text. Legacy Office files and unsupported binaries require conversion to PDF or TXT. Generated reasoning questions are practice, not a standardized IQ test.

Google Gemini receives uploaded content only when the user requests analysis. ThinkX stores generated summaries, questions, attempts, feedback and profiles in D1. Original upload bytes are not retained by ThinkX.
