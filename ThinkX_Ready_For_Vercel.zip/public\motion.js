/* View enhancements only. The existing bilingual learning logic lives in app.js. */
(() => {
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const root = document.documentElement;
  const systemMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = matchMedia('(hover: hover) and (pointer: fine)');
  const stored = (key, fallback=null) => { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } };
  const save = (key,value) => { try { localStorage.setItem(key,value); } catch {} };
  const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const lang = () => root.lang === 'ar' ? 'ar' : 'en';
  const copy = {
    ar:{workspace:'مساحتك',small_steps:'خطوات صغيرة. معرفة أكبر.',small_steps_sub:'خُد وقتك، واستمتع بالتعلّم.',your_space:'مساحتك للتعلّم',eyebrow:'شوية فضول. عوالم جديدة.',hero_sub:'اكتشف، جرّب، وافهم. معرفتك بتكبر مع كل خطوة.',learning_session:'جلسة التعلّم',choose_answer:'اختر الإجابة الصحيحة',visual_learning:'تعلّم بالصورة',drag_scene:'اسحب لتدوير المشهد',no_rush:'خُد وقتك، الفهم أهم من السرعة.',a_little_insight:'فكرة توسّع مداركك',focus_title:'لحظة للتركيز',focus_sub:'مساحة هادية لعقلك',skip_question:'عدّي السؤال',footer_note:'المعرفة رحلة، مش سباق.',motion_setting:'تقليل الحركة',glass_setting:'تأثير الزجاج الشفاف',auth_heading:'خلي رحلتك ليها مكان.',local_profile:'ملفك وتقدّمك بيتحفظوا على المتصفح ده.',continue_guest:'جرّب بدون حساب',assistant_local:'مساعد تعليمي محلي • شروحات وتلميحات',all_tools:'كل أدواتك',dock_home:'الرئيسية',dock_learn:'اكتشف',dock_cards:'المراجعة',dock_typing:'الكتابة',dock_more:'المزيد',search_hint:'اكتب اسم أداة أو موضوع في بنك الأسئلة',search_placeholder:'ابحث عن أداة أو موضوع…',daily_goal:'خطوتك النهارده',daily_note:'هدف بسيط: 5 أسئلة في اليوم. على مهلك.',focus_start:'ابدأ مؤقت التركيز',focus_pause:'أوقف المؤقت مؤقتًا',focus_reset:'إعادة ضبط مؤقت التركيز',scene_reset:'إعادة ضبط المشهد',scene_label:'مجسّم تفاعلي. اسحب يمينًا أو يسارًا، أو استخدم الأسهم للتدوير وHome لإعادة الضبط.',search_empty:'مفيش نتائج هنا. جرّب اسم أداة أو موضوع تاني.',tools:'أداة تعلّم',flashcard:'بطاقة مراجعة',focus_done:'خمس دقائق من التركيز. خُد نفس وراحة صغيرة.',correct:'إجابة صحيحة! ',incorrect:'فرصة جديدة للتعلّم. ',daily_done:'أجبت عن 5 أسئلة النهارده. خطوة جميلة!',profile_guest:'جلسة ضيف · التقدّم محفوظ في الجلسة دي',translate_hint:'قلب بطاقة للمراجعة أو جرّب أداة تانية.',search_label:'ابحث في ThinkX',notifications:'نشاطك اليوم',close:'إغلاق',sound:'اسمع السؤال',flip:'اقلب بطاقة المراجعة',skip_link:'انتقل إلى المحتوى'},
    en:{workspace:'YOUR WORKSPACE',small_steps:'Small steps. Bigger discoveries.',small_steps_sub:'Take your time. Enjoy the learning.',your_space:'Your learning space',eyebrow:'A LITTLE CURIOSITY. A WHOLE NEW WORLD.',hero_sub:'Discover, explore, understand. Grow a little with every step.',learning_session:'LEARNING SESSION',choose_answer:'Choose the right answer',visual_learning:'A NEW PERSPECTIVE',drag_scene:'Drag to explore',no_rush:'Take your time. Understanding comes first.',a_little_insight:'A LITTLE SOMETHING TO KNOW',focus_title:'A moment to focus',focus_sub:'A little breathing room',skip_question:'Skip for now',footer_note:'Knowledge is a journey. Find your pace.',motion_setting:'Reduce motion',glass_setting:'Transparent glass effects',auth_heading:'Make space for your curiosity.',local_profile:'Your profile and progress stay in this browser.',continue_guest:'Explore as a guest',assistant_local:'Local learning guide • hints & explanations',all_tools:'All your tools',dock_home:'Home',dock_learn:'Explore',dock_cards:'Review',dock_typing:'Typing',dock_more:'More',search_hint:'Search for a tool or a topic in the question bank',search_placeholder:'Find a tool or a topic…',daily_goal:'Your step today',daily_note:'A simple goal: 5 questions a day. At your pace.',focus_start:'Start focus timer',focus_pause:'Pause focus timer',focus_reset:'Reset focus timer',scene_reset:'Reset the scene',scene_label:'Interactive model. Drag horizontally or use arrow keys to rotate. Press Home to reset.',search_empty:'No matches yet. Try another tool or topic.',tools:'Learning tool',flashcard:'Review flashcard',focus_done:'Five minutes of focus. Take a breath and a little break.',correct:'You got it! ',incorrect:'A new opportunity to learn. ',daily_done:'Five questions today. A lovely step forward!',profile_guest:'Guest session · progress stays in this session',translate_hint:'Flip a review card or try another tool.',search_label:'Search ThinkX',notifications:'Your activity today',close:'Close',sound:'Listen to the question',flip:'Flip the review card',skip_link:'Skip to content'}
  };
  const t = key => copy[lang()][key] || key;
  Object.assign(copy.ar,{
    header_caption:'مساحة صغيرة، لفضول كبير.',eyebrow:'لحظة فضول، عالم من المعرفة.',hero_sub:'اختار، اكتشف، وافهم. كل خطوة تفتح لك فكرة جديدة.',
    dock_translate:'المترجم',dock_reading:'القراءة',dock_progress:'تقدّمي',theme_label:'تغيير المظهر الفاتح والداكن'
  });
  Object.assign(copy.en,{
    header_caption:'A little space for a curious mind.',eyebrow:'A LITTLE CURIOSITY. A WHOLE NEW WORLD.',hero_sub:'Discover, explore, understand. A fresh perspective with every step.',
    dock_translate:'Translate',dock_reading:'Reading',dock_progress:'Progress',theme_label:'Switch between light and dark'
  });
  let toastTimeout;
  function toast(message) {
    const box=$('#glassToast'); box.textContent=message; box.classList.add('visible');
    clearTimeout(toastTimeout); toastTimeout=setTimeout(()=>box.classList.remove('visible'),3800);
  }

  function reduced(){ return root.dataset.motion === 'reduced' || systemMotion.matches; }
  function applyPreferences(){
    const reduce=stored('thinkx_reduce_motion','false') === 'true' || systemMotion.matches;
    root.dataset.motion=reduce?'reduced':'full';
    root.dataset.glass=stored('thinkx_glass','true')==='false'?'solid':'glass';
    $('#motionToggle').checked=reduce; $('#glassToggle').checked=root.dataset.glass==='glass';
  }
  applyPreferences();
  function applyTheme(){
    root.dataset.theme=stored('thinkx_theme','light');
    $('#btnThemeToggle').setAttribute('aria-pressed',String(root.dataset.theme==='dark'));
    document.querySelector('meta[name="theme-color"]').content=root.dataset.theme==='dark'?'#152743':'#dfe8f8';
  }
  applyTheme();
  $('#btnThemeToggle').addEventListener('click',()=>{
    save('thinkx_theme',root.dataset.theme==='light'?'dark':'light');applyTheme();
  });
  $('#motionToggle').addEventListener('change',e=>{ save('thinkx_reduce_motion',String(e.target.checked)); applyPreferences(); stopMotion(); });
  $('#glassToggle').addEventListener('change',e=>{ save('thinkx_glass',String(e.target.checked)); applyPreferences(); });
  systemMotion.addEventListener('change',()=>{applyPreferences();stopMotion();});
  $('#settingsSoundToggle').checked=stored('thinkx_sound','true')!=='false';
  $('#settingsSoundToggle').addEventListener('change',e=>save('thinkx_sound',String(e.target.checked)));

  function localize(){
    $$('[data-glass-i18n]').forEach(node=>{ node.textContent=t(node.dataset.glassI18n); });
    $$('[data-glass-placeholder]').forEach(node=>{node.placeholder=t(node.dataset.glassPlaceholder);});
    $('#sceneStage').setAttribute('aria-label',t('scene_label'));
    $('#btnResetScene').setAttribute('aria-label',t('scene_reset'));
    $('#btnResetScene').title=t('scene_reset');
    $('#btnFocusReset').setAttribute('aria-label',t('focus_reset'));
    $('#btnSpeechSynthesis').setAttribute('aria-label',t('sound'));
    $('#btnSpeechSynthesis').title=t('sound');
    $('#btnNotifications').setAttribute('aria-label',t('notifications'));
    $('#btnNotifications').title=t('notifications');
    $('#flashcardBox').setAttribute('aria-label',t('flip'));
    $('.skip-link').textContent=t('skip_link');
    $('#searchTitle').textContent=t('search_label');
    $('#searchConceptsInput').setAttribute('aria-label',t('search_label'));
    $('#searchConceptsInput').value='';
    $('#btnThemeToggle').setAttribute('aria-label',t('theme_label'));
    $('#btnThemeToggle').title=t('theme_label');
    $('#btnNewSession').setAttribute('aria-label',lang()==='ar'?'جلسة جديدة':'New session');
    $('#btnNewSession').title=lang()==='ar'?'جلسة جديدة':'New session';
    $('#btnAiSuggestions').setAttribute('aria-label',lang()==='ar'?'مساعد التعلّم':'Learning guide');
    $('#userProfileBadge').setAttribute('aria-label',lang()==='ar'?'ملفي الشخصي':'My profile');
    [$('#closeSearch'),$('#btnCloseMore'),$('#closeActivity')].forEach(node=>node.setAttribute('aria-label',t('close')));
    if(window.thinkxStats?.isGuest) $('#sidebarTierText').textContent=t('profile_guest');
    updateSection($('.app-section.active-section')?.id.replace('section-','')||'quiz');
    updateQuestion(window.thinkxCurrentQuestion);
    updateDailyGoal(); updateFocus();
    if(!$('#searchOverlay').hidden) renderSearch($('#commandInput').value);
  }

  const sceneMarkup = {
    globe:'<div class="globe-model"><div class="meridian m1"></div><div class="meridian m2"></div><div class="latitude l1"></div><div class="latitude l2"></div><div class="latitude l3"></div><svg class="globe-land" viewBox="0 0 145 145"><path d="m48 24 16-6 10 7 14 2 4 10-11 6-2 14-12 3-5 15-13-6-8-14 4-13-5-9Z"/><path d="m62 73 15 1 10 12-4 14-10 21-9-5-2-14-7-16Z"/><path d="m98 38 15 4 8 19-8 7-1 14-12-5-3-12-9-4 2-13Z"/></svg><span class="globe-pin"></span><div class="globe-shine"></div></div>',
    solar:'<div class="solar-model"><span class="star-dot"></span><div class="solar-orbit"></div><div class="solar-orbit"></div><div class="solar-orbit"></div><div class="solar-sun"></div><div class="solar-planet"></div><div class="solar-planet p2"></div><div class="solar-planet p3"></div></div>',
    atom:'<div class="atom-model"><div class="atom-orbit"></div><div class="atom-orbit"></div><div class="atom-orbit"></div><div class="atom-core"></div></div>',
    cube:'<div class="cube-model"><div class="cube-face front"></div><div class="cube-face back"></div><div class="cube-face right"></div><div class="cube-face left"></div><div class="cube-face top"></div><div class="cube-face bottom"></div></div><div class="cube-dot"></div>',
    sprout:'<div class="sprout-model"><div class="sprout-stem"></div><div class="sprout-leaf"></div><div class="sprout-leaf leaf2"></div><div class="sprout-ring"></div></div>',
    history:'<div class="history-model"><div class="pyramid second"></div><div class="pyramid"></div><div class="history-base"></div></div>'
  };
  const sceneCopy={
    ar:{globe:['العالم أكبر من حدودنا.','مدن، قارات، وحكايات تستنّى فضولك.'],solar:['ارفع عينك، أبعد شوية.','من الكواكب للنجوم… استكشف أسرار الكون.'],atom:['تفاصيل صغيرة، عالم كبير.','العلوم بتفتح لنا نافذة على ما لا نراه.'],cube:['الفكرة ليها أكتر من بُعد.','دوّر المجسّم، وجرّب تشوفه من زاوية جديدة.'],sprout:['كل معرفة، بذرة جديدة.','استكشف العالم الحي وروعة تفاصيله.'],history:['كل أثر وراه حكاية.','رحلة بين الحضارات والأفكار اللي غيّرت العالم.']},
    en:{globe:['A world beyond your borders.','Cities, continents, and stories waiting for your curiosity.'],solar:['Look up. Then a little further.','From planets to stars, explore the universe.'],atom:['Tiny details. A whole new world.','Science opens a window onto the things we cannot see.'],cube:['There is more than one angle.','Rotate the model. Give the idea a new perspective.'],sprout:['Every discovery starts a seed.','Explore the living world and its extraordinary details.'],history:['Every trace tells a story.','A journey through civilizations and world-changing ideas.']}
  };
  function sceneFor(q){
    const c=(q?.category_en||'').toLowerCase();
    if(/geography|general/.test(c))return'globe';
    if(/astronomy|cosmology/.test(c))return'solar';
    if(/history|civilization|art/.test(c))return'history';
    if(/nature|biology/.test(c))return'sprout';
    if(/mathematics|computer|invention|linguistic/.test(c))return'cube';
    return'atom';
  }
  let currentScene='';
  function updateQuestion(q){
    if(!q)return;
    const scene=sceneFor(q);
    if(currentScene!==scene){ $('#sceneObject').innerHTML=sceneMarkup[scene]; currentScene=scene; }
    $('#visualQuestion').dataset.scene=scene;
    $('#sceneObject').setAttribute('aria-hidden','true');
    $('#questionNumber').textContent=String(q.number||1).padStart(2,'0');
    $('#questionCategory').textContent=q['category_'+lang()]||'';
    $('#sceneTitle').textContent=sceneCopy[lang()][scene][0];
    $('#sceneDescription').textContent=sceneCopy[lang()][scene][1];
    $('#answerFeedback').hidden=true;
    const n=Math.min(4,Math.max(0,(q.number||1)-1));
    $$('#questionSteps i').forEach((dot,i)=>{dot.classList.toggle('current',i===n);dot.classList.toggle('done',i<n);});
    $('#questionSteps').setAttribute('aria-label',lang()==='ar'?`السؤال ${n+1} من 5`:`Question ${n+1} of 5`);
    resetScene();
    if(!reduced())requestAnimationFrame(()=>{
      $$('#optionsContainer .option-btn').forEach((node,i)=>{
        node.animate([{opacity:0,transform:'translateY(6px)'},{opacity:1,transform:'translateY(0)'}],{duration:270,delay:i*35,easing:'cubic-bezier(.2,.8,.2,1)'});
      });
    });
  }

  // One animation frame loop, scheduled only while an interacted scene is moving.
  const stage=$('#sceneStage'), object=$('#sceneObject');
  let rx=-10,ry=-16,targetX=rx,targetY=ry,baseX=rx,baseY=ry,frame=0,lastFrame=0;
  let drag=null,hoverRect=null;
  function paint(){object.style.setProperty('--rx',`${rx.toFixed(3)}deg`);object.style.setProperty('--ry',`${ry.toFixed(3)}deg`);}
  function tick(now){
    if(document.hidden){frame=0;lastFrame=0;return;}
    const dt=lastFrame?Math.min(40,now-lastFrame):16;lastFrame=now;
    const amount=1-Math.exp(-dt/65);
    rx+=(targetX-rx)*amount;ry+=(targetY-ry)*amount;paint();
    if(Math.abs(targetX-rx)+Math.abs(targetY-ry)>.025)frame=requestAnimationFrame(tick);
    else{rx=targetX;ry=targetY;paint();frame=0;lastFrame=0;object.style.willChange='';}
  }
  function schedule(){
    if(reduced()){stopMotion();rx=targetX;ry=targetY;paint();return;}
    if(!frame){object.style.willChange='transform';frame=requestAnimationFrame(tick);}
  }
  function stopMotion(){if(frame)cancelAnimationFrame(frame);frame=0;lastFrame=0;object.style.willChange='';}
  function resetScene(){baseX=-10;baseY=-16;targetX=baseX;targetY=baseY;schedule();}
  stage.addEventListener('pointerenter',()=>{hoverRect=stage.getBoundingClientRect();});
  stage.addEventListener('pointerdown',e=>{
    if(e.button!==0)return;
    drag={x:e.clientX,y:e.clientY,rx:targetX,ry:targetY,id:e.pointerId};
    stage.classList.add('dragging');stage.setPointerCapture(e.pointerId);
  });
  stage.addEventListener('pointermove',e=>{
    if(drag){
      targetY=drag.ry+(e.clientX-drag.x)*.6;
      targetX=Math.max(-50,Math.min(45,drag.rx-(e.clientY-drag.y)*.35));schedule();
    }else if(finePointer.matches&&!reduced()){
      if(!hoverRect)hoverRect=stage.getBoundingClientRect();
      targetY=baseY+((e.clientX-hoverRect.left)/hoverRect.width-.5)*12;
      targetX=baseX-((e.clientY-hoverRect.top)/hoverRect.height-.5)*8;schedule();
    }
  },{passive:true});
  function endDrag(e){
    if(!drag)return;
    baseX=targetX;baseY=targetY;drag=null;stage.classList.remove('dragging');
    if(stage.hasPointerCapture(e.pointerId))stage.releasePointerCapture(e.pointerId);
  }
  stage.addEventListener('pointerup',endDrag);stage.addEventListener('pointercancel',endDrag);
  stage.addEventListener('pointerleave',()=>{if(!drag){targetX=baseX;targetY=baseY;schedule();}});
  stage.addEventListener('keydown',e=>{
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home'].includes(e.key))return;
    e.preventDefault();if(e.key==='Home'){resetScene();return;}
    if(e.key==='ArrowLeft')targetY-=12;if(e.key==='ArrowRight')targetY+=12;
    if(e.key==='ArrowUp')targetX=Math.max(-50,targetX-8);if(e.key==='ArrowDown')targetX=Math.min(45,targetX+8);
    baseX=targetX;baseY=targetY;schedule();
  });
  $('#btnResetScene').addEventListener('click',resetScene);
  window.addEventListener('resize',()=>{hoverRect=null;},{passive:true});

  // Focus uses elapsed wall time, so background tabs do not make it drift.
  let focusSeconds=300,focusDeadline=0,focusRunning=false,focusInterval=null;
  try{
    const saved=JSON.parse(sessionStorage.getItem('thinkx_focus')||'null');
    if(saved){focusSeconds=Math.max(0,Math.min(300,saved.remaining||300));focusDeadline=saved.deadline||0;focusRunning=!!saved.running;}
  }catch{}
  function saveFocus(){try{sessionStorage.setItem('thinkx_focus',JSON.stringify({remaining:focusSeconds,deadline:focusDeadline,running:focusRunning}));}catch{}}
  function updateFocus(){
    if(focusRunning){
      focusSeconds=Math.max(0,Math.ceil((focusDeadline-Date.now())/1000));
      if(focusSeconds===0){focusRunning=false;clearInterval(focusInterval);focusInterval=null;saveFocus();toast(t('focus_done'));}
    }
    $('#focusTime').textContent=`${String(Math.floor(focusSeconds/60)).padStart(2,'0')}:${String(focusSeconds%60).padStart(2,'0')}`;
    $('#focusProgress').style.width=`${(300-focusSeconds)/3}%`;
    $('.focus-widget').classList.toggle('running',focusRunning);
    $('#btnFocusToggle').innerHTML=icon(focusRunning?'pause':'play');
    $('#btnFocusToggle').setAttribute('aria-label',t(focusRunning?'focus_pause':'focus_start'));
    $('#btnFocusToggle').setAttribute('aria-pressed',String(focusRunning));
  }
  $('#btnFocusToggle').addEventListener('click',()=>{
    if(focusRunning){updateFocus();focusRunning=false;clearInterval(focusInterval);focusInterval=null;}
    else{if(focusSeconds===0)focusSeconds=300;focusDeadline=Date.now()+focusSeconds*1000;focusRunning=true;focusInterval=setInterval(updateFocus,1000);}
    updateFocus();saveFocus();
  });
  $('#btnFocusReset').addEventListener('click',()=>{focusRunning=false;focusSeconds=300;focusDeadline=0;clearInterval(focusInterval);focusInterval=null;saveFocus();updateFocus();});
  if(focusRunning){updateFocus();if(focusRunning)focusInterval=setInterval(updateFocus,1000);}
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stopMotion();else updateFocus();});

  function dailyKey(){const d=new Date();const day=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;return`thinkx_daily_${day}_${window.thinkxStats?.userKey||'visitor'}`;}
  function dailyCount(){return Math.max(0,Number(stored(dailyKey(),'0'))||0);}
  function updateDailyGoal(){
    const n=dailyCount();
    $('#dailyGoalText').textContent=lang()==='ar'?`أجبت عن ${n} من 5 أسئلة النهارده.`:`You have answered ${n} of 5 questions today.`;
    $('#dailyGoalBar').style.width=`${Math.min(100,n*20)}%`;
  }
  window.addEventListener('thinkx:answered',e=>{
    const n=dailyCount()+1;save(dailyKey(),String(n));updateDailyGoal();
    const q=e.detail.question;
    const feedback=$('#answerFeedback');feedback.textContent=t(e.detail.correct?'correct':'incorrect')+q['explanation_'+lang()];
    feedback.classList.toggle('error',!e.detail.correct);feedback.hidden=false;
    if(n===5)toast(t('daily_done'));
  });
  window.addEventListener('thinkx:stats',()=>{updateDailyGoal();if(window.thinkxStats?.isGuest)$('#sidebarTierText').textContent=t('profile_guest');});

  const more=$('#moreSheet'),moreOverlay=$('#moreOverlay'),moreButton=$('#btnMore'),searchOverlay=$('#searchOverlay');
  let returnFocus=null,activeDialog=null,restoringFocus=false;
  function visibleDialogs(){
    const result=$$('.modal-overlay.open [role=dialog]');
    if(!more.hidden)result.push(more);
    if(!searchOverlay.hidden)result.push($('.search-dialog'));
    return result;
  }
  function syncDialogs(){
    const dialogs=visibleDialogs();const next=dialogs.at(-1)||null;
    $$('.modal-overlay').forEach(n=>n.setAttribute('aria-hidden',String(!n.classList.contains('open'))));
    $('.app-container').inert=!!next;$('.glass-dock').inert=!!next;
    document.body.style.overflow=next?'hidden':'';
    if(next!==activeDialog){
      if(next){
        if(!activeDialog)returnFocus=document.activeElement;
        activeDialog=next;
        const first=$('input:not([type=hidden]),button,[href],[tabindex="0"]',next)||next;
        first.focus({preventScroll:true});
      }else{
        activeDialog=null;
        if(returnFocus?.isConnected&&returnFocus.getClientRects().length){
          restoringFocus=true;returnFocus.focus({preventScroll:true});restoringFocus=false;
        }
        returnFocus=null;
      }
    }
  }
  const modalObserver=new MutationObserver(syncDialogs);
  $$('.modal-overlay').forEach(n=>{modalObserver.observe(n,{attributes:true,attributeFilter:['class']});n.addEventListener('click',e=>{if(e.target===n)closeTopDialog();});});
  function closeMore(){more.hidden=true;moreOverlay.hidden=true;moreButton.setAttribute('aria-expanded','false');syncDialogs();}
  function openMore(){
    more.hidden=false;moreOverlay.hidden=false;moreButton.setAttribute('aria-expanded','true');syncDialogs();
    if(!reduced())more.animate([{opacity:0,transform:'translate(-50%,30px)'},{opacity:1,transform:'translate(-50%,0)'}],{duration:300,easing:'cubic-bezier(.2,.8,.2,1)'});
  }
  moreButton.addEventListener('click',()=>more.hidden?openMore():closeMore());
  $('#btnCloseMore').addEventListener('click',closeMore);moreOverlay.addEventListener('click',closeMore);
  function openSearch(value=''){
    if(!more.hidden)closeMore();
    $('#activityPopover').hidden=true;searchOverlay.hidden=false;
    $('#commandInput').value=value;renderSearch(value);syncDialogs();$('#commandInput').focus();
  }
  function closeSearch(){searchOverlay.hidden=true;syncDialogs();}
  $('#closeSearch').addEventListener('click',closeSearch);
  searchOverlay.addEventListener('click',e=>{if(e.target===searchOverlay)closeSearch();});
  $('#searchConceptsInput').addEventListener('focus',()=>{if(!restoringFocus)openSearch();});
  $('#searchConceptsInput').addEventListener('click',()=>{if(searchOverlay.hidden)openSearch();});
  $('#commandInput').addEventListener('input',e=>renderSearch(e.target.value));
  function closeTopDialog(){
    if(!searchOverlay.hidden){closeSearch();return;}
    if(!more.hidden){closeMore();return;}
    const overlay=$$('.modal-overlay.open').at(-1);
    if(overlay){const close=$('.modal-close-btn,#closeCelebModal',overlay);if(close)close.click();else overlay.classList.remove('open');}
  }
  document.addEventListener('keydown',e=>{
    if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openSearch();return;}
    if(e.key==='Escape'){$('#activityPopover').hidden=true;$('#btnNotifications').setAttribute('aria-expanded','false');closeTopDialog();return;}
    if(e.key==='Tab'&&activeDialog){
      const list=$$('button:not(:disabled),input:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]',activeDialog).filter(n=>n.getClientRects().length);
      if(!list.length){e.preventDefault();activeDialog.focus();return;}
      const first=list[0],last=list.at(-1);
      if(e.shiftKey&&(document.activeElement===first||!activeDialog.contains(document.activeElement))){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&(document.activeElement===last||!activeDialog.contains(document.activeElement))){e.preventDefault();first.focus();}
    }
  });

  const toolIcons={dashboard:'grid',quiz:'compass',typing:'keyboard',translator:'language',reading:'book',study:'cards',progress:'chart',settings:'settings',lab:'book',coach:'spark',classroom:'cards',iq:'compass',teacher:'grid',builder:'plus'};
  function updateDock(){
    const dock=$('.glass-dock');
    const active=$('.dock-item.active',dock);
    if(!active)return;
    const outer=dock.getBoundingClientRect(),inner=active.getBoundingClientRect();
    dock.style.setProperty('--dock-x',`${inner.left-outer.left-1}px`);
    dock.style.setProperty('--dock-w',`${inner.width}px`);
    dock.style.setProperty('--dock-ready','1');
  }
  function renderSearch(query=''){
    const holder=$('#searchResults');holder.replaceChildren();const value=query.trim().toLocaleLowerCase();
    const tools=Object.entries(toolIcons).map(([section,ic])=>{
      const names={lab:'استوديو المذاكرة',coach:'Gemini مساعد',classroom:'غرفة الفصل',iq:'تحدّي القدرات',teacher:'لوحة المعلم',builder:'تجهيز اختبار'};const label=names[section]||$(`.nav-link[data-section="${section}"] [data-i18n]`)?.textContent||section;
      return{section,ic,label,sub:t('tools'),search:`${label} ${section}`};
    }).filter(item=>!value||item.search.toLocaleLowerCase().includes(value));
    const questions=value&&typeof QUIZ_QUESTIONS!=='undefined'?QUIZ_QUESTIONS.filter(q=>`${q.question_ar} ${q.question_en} ${q.category_ar} ${q.category_en}`.toLocaleLowerCase().includes(value)).slice(0,7).map(q=>({id:q.id,ic:'cards',label:q['question_'+lang()],sub:`${t('flashcard')} · ${q['category_'+lang()]}`})):[];
    const list=[...tools,...questions];
    if(!list.length){const p=document.createElement('p');p.className='search-empty';p.textContent=t('search_empty');holder.append(p);return;}
    list.forEach(item=>{
      const button=document.createElement('button');button.className='search-result';
      button.innerHTML=icon(item.ic)+'<span><span></span><small></small></span>';
      $('span>span',button).textContent=item.label;$('small',button).textContent=item.sub;
      button.addEventListener('click',()=>{
        closeSearch();
        if(item.section)window.switchSection(item.section);
        else window.thinkxReviewQuestion?.(item.id);
      });holder.append(button);
    });
  }
  function updateSection(section){
    const nav=$(`.nav-link[data-section="${section}"] [data-i18n]`);
    $('#currentSectionLabel').textContent=nav?.textContent||'';
    $$('.more-grid [data-go]').forEach(n=>n.classList.toggle('active',n.dataset.go===section));
    const direct=$(`.dock-item[data-go="${section}"]`);
    const directVisible=direct&&direct.getClientRects().length>0;
    moreButton.classList.toggle('active',!directVisible);
    moreButton.setAttribute('aria-current',moreButton.classList.contains('active')?'page':'false');
    document.title=`ThinkX — ${nav?.textContent||'Stay curious'}`;
    requestAnimationFrame(updateDock);
  }
  $$('[data-go]').forEach(node=>node.addEventListener('click',e=>{
    e.preventDefault();const section=node.dataset.go;if(!more.hidden)closeMore();window.switchSection(section);
  }));
  window.addEventListener('thinkx:section',e=>{updateSection(e.detail);$('#activityPopover').hidden=true;});
  window.addEventListener('hashchange',()=>{const sec=location.hash.slice(1);if(document.getElementById(`section-${sec}`))window.switchSection(sec,{skipHistory:true});});
  window.addEventListener('resize',()=>updateSection($('.app-section.active-section')?.id.replace('section-','')||'quiz'),{passive:true});
  window.addEventListener('thinkx:language',localize);
  window.addEventListener('thinkx:question',e=>updateQuestion(e.detail));
  window.addEventListener('thinkx:notice',e=>toast(e.detail));
  $('#flashcardBox').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.currentTarget.click();}});
  function syncFlashcard(){
    const box=$('#flashcardBox'),flipped=box.classList.contains('flipped');
    $('.flashcard-front',box).setAttribute('aria-hidden',String(flipped));
    $('.flashcard-back',box).setAttribute('aria-hidden',String(!flipped));
    box.setAttribute('aria-pressed',String(flipped));
  }
  new MutationObserver(syncFlashcard).observe($('#flashcardBox'),{attributes:true,attributeFilter:['class']});
  syncFlashcard();
  $('#userProfileBadge').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.currentTarget.click();}});
  $('#btnNotifications').setAttribute('aria-expanded','false');
  $('#btnNotifications').addEventListener('click',()=>{
    const box=$('#activityPopover');box.hidden=!box.hidden;$('#btnNotifications').setAttribute('aria-expanded',String(!box.hidden));updateDailyGoal();
  });
  $('#closeActivity').addEventListener('click',()=>{$('#activityPopover').hidden=true;$('#btnNotifications').setAttribute('aria-expanded','false');});
  document.addEventListener('click',e=>{if(!e.target.closest('#activityPopover,#btnNotifications')){$('#activityPopover').hidden=true;$('#btnNotifications').setAttribute('aria-expanded','false');}});
  syncDialogs();localize();paint();
})();
