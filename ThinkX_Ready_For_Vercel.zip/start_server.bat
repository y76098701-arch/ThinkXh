@echo off
title ThinkX Server
cd /d "%~dp0"
echo Starting ThinkX Local Server...
agy-node server.mjs
pause
